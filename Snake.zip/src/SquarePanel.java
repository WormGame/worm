import java.awt.Color;
import javax.swing.JPanel;
/*
* 사각형 생성 클래스
* 생성자에서 Color 지정으로 JPanel 백그라운드 색상 지정
* colorType
* 	2: snake
* 	1: food
*	0: empty
*/
public class SquarePanel extends JPanel{
	/*
	 * true: 정상
	 * false: 비정상
	 */
	private boolean checkColorType(int colorType){
		ColorContainer mColorContainer = ColorContainer.getInstance();
		if(colorType >= mColorContainer.getSize()){
			return false;
		}
		return true;
	}
	
	private Color getColor(int colorType) throws IllegalArgumentException{
		if(!checkColorType(colorType)){
			throw new IllegalArgumentException();
		}
		ColorContainer mColorContainer = ColorContainer.getInstance();
		return mColorContainer.getColor(colorType);
	}
	
	public SquarePanel(int colorType) throws IllegalArgumentException{
		this.setBackground(getColor(colorType));
	}
	
	public void changeColor(int colorType) throws IllegalArgumentException{
		this.setBackground(getColor(colorType));
		this.repaint();
	}
	
}

