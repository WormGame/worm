import java.awt.*;
import java.util.ArrayList;

/*
* 싱글톤 클래스
* 처음 생성시 기본 색상 ArrayList에 추가
 */
public class ColorContainer {
    private ArrayList<Color> mColors;
    
    private static ColorContainer mColorContainerInst;
    
    public final static int SNAKE_COLOR_TYPE = 2;
    
    public final static int FOOD_COLOR_TYPE = 1;
    
    public final static int EMPTY_COLOR_TYPE = 0;
    
    
    public static synchronized ColorContainer getInstance() {
        if(mColorContainerInst == null){
            mColorContainerInst = new ColorContainer();
            mColorContainerInst.mColors = new ArrayList<Color>();
            mColorContainerInst.mColors.add(Color.white);
            mColorContainerInst.mColors.add(Color.BLUE);
            mColorContainerInst.mColors.add(Color.darkGray);
        }
        return mColorContainerInst;
    }
    
    public Color getColor(int colorType){
        return this.mColors.get(colorType);
    }
    
    public int getSize(){
        return mColors.size();
    }
}
