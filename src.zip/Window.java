import java.awt.GridLayout;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.JFrame;

/*
* 지렁이 생성

 */
class Window extends JFrame{
	private static final long serialVersionUID = -2542001418764869760L;
	
	public static ArrayList<ArrayList<SquarePanel>> mGridMap;
	
	public final static int WIDTH = 20;
	
	public final static int HEIGHT = 20;
	
	public Window(){
		// Creates the arraylist that'll contain the threads
		mGridMap = new ArrayList<ArrayList<SquarePanel>>();
		ArrayList<SquarePanel> data;
		
		// Creates Threads and its data and adds it to the arrayList
		SquarePanel square;
		for(int col = 0; col < WIDTH; col++){
			data = new ArrayList<SquarePanel>();
			for(int row = 0; row < HEIGHT; row++){
				square = new SquarePanel(ColorContainer.EMPTY_COLOR_TYPE);
				data.add(square);
			}
			mGridMap.add(data);
		}
		
		// Setting up the layout of the panel
		getContentPane().setLayout(new GridLayout(20,20,0,0));
		
		// Start & pauses all threads, then adds every square of each thread to the panel

		
		for(int col = 0; col < WIDTH; col++){
			for(int row = 0; row < HEIGHT; row++){
				square = mGridMap.get(col).get(row);
				getContentPane().add(square);
			}
		}
		
		// initial position of the snake
		Tuple position = new Tuple(10,10);
		// passing this value to the controller
		ThreadsController c = new ThreadsController(position);
		//Let's start the game now..
		c.start();

		// Links the window to the keyboardlistenner.
		this.addKeyListener((KeyListener) new KeyboardListener());

		//To do : handle multiplayers .. The above works, test it and see what happens
		
		//Tuple position2 = new Tuple(13,13);
		//ControlleurThreads c2 = new ControlleurThreads(position2);
		//c2.start();
		
	}
}
